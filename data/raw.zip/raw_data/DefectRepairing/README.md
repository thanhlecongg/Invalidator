The source code and some necessary scripts of our tool are in `./tool`. Please refer to "readme.md" in the directory "./tool" for details about tool setup.

All the patch we collected are in `./tool/patches`

The detailed result of our experiment are in `./results`
